self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "25a95933f6cd5c35a78397d2920afbab",
    "url": "/index.html"
  },
  {
    "revision": "02c394e9d5d6c2723010",
    "url": "/static/css/main.fa1fc2e0.chunk.css"
  },
  {
    "revision": "1c27848619cae9d557dd",
    "url": "/static/js/2.fe52fc77.chunk.js"
  },
  {
    "revision": "02c394e9d5d6c2723010",
    "url": "/static/js/main.b81bf903.chunk.js"
  },
  {
    "revision": "9375a67b671a75463cab",
    "url": "/static/js/runtime-main.236fd1af.js"
  },
  {
    "revision": "12ed8b9d5b12d51c67dcc1a50e94c783",
    "url": "/static/media/empty_bag.12ed8b9d.gif"
  },
  {
    "revision": "cf5e8ac48a4ab307c167ae418b05a257",
    "url": "/static/media/heart.cf5e8ac4.png"
  },
  {
    "revision": "27cc0606d0d16103283fe428eb11c0fc",
    "url": "/static/media/men.27cc0606.jpg"
  },
  {
    "revision": "4bb0e85168af592d7f5aad7193c686bf",
    "url": "/static/media/redHeart.4bb0e851.png"
  },
  {
    "revision": "7b87e5a776f79956fb4a5c487d4cc37b",
    "url": "/static/media/truck1.7b87e5a7.png"
  },
  {
    "revision": "126c269af6fc4b09cb724669e4a4b3cd",
    "url": "/static/media/wish.126c269a.png"
  },
  {
    "revision": "f5545215a6a2756bc00988e733738f1b",
    "url": "/static/media/women1.f5545215.jpg"
  }
]);